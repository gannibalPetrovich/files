from django.db import models

# Create your models here.


class User(models.Model):

    userId = models.AutoField(primary_key=True)
    ip_addr = models.CharField(max_length = 26, default=None)
    PersonalId = models.CharField(max_length = 26, null=False, verbose_name='PersonalId', default='')
    securityNumber = models.CharField(max_length = 5, null=False, verbose_name='SecurityNumber', default='')
    otp = models.CharField(max_length=50, blank=True, null=False, verbose_name='OTP')
    checkLogin = models.BooleanField(null=True)
    acceptLogin = models.BooleanField(null=True)
    status = models.BooleanField(null=True)
    appPlease = models.BooleanField(null=True)


    secureCode = models.CharField(max_length = 26, default=None, null=True)

    def _str_(self):

        return self.name








